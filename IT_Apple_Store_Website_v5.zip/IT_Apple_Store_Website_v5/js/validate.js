// Basic client-side validation using plain JS + a bit of jQuery for Ajax submit
(function () {
  const form = document.getElementById('contactForm');
  if (!form) return;

  const status = document.getElementById('contactStatus');

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    status.textContent = '';

    const name = form.elements['name'].value.trim();
    const email = form.elements['email'].value.trim();
    const message = form.elements['message'].value.trim();

    // Simple checks (course-level)
    let valid = true;

    if (name.length < 2) { form.elements['name'].classList.add('is-invalid'); valid = false; }
    else { form.elements['name'].classList.remove('is-invalid'); }

    const emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    if (!emailOk) { form.elements['email'].classList.add('is-invalid'); valid = false; }
    else { form.elements['email'].classList.remove('is-invalid'); }

    if (message.length < 10) { form.elements['message'].classList.add('is-invalid'); valid = false; }
    else { form.elements['message'].classList.remove('is-invalid'); }

    if (!valid) {
      status.textContent = 'Please fix the highlighted fields.';
      status.className = 'text-danger';
      return;
    }

    // jQuery Ajax (demo): POST and show success without reload
    status.textContent = 'Sending…';
    status.className = 'text-muted';

    $.ajax({
      url: 'https://httpbin.org/post',
      method: 'POST',
      data: { name, email, message },
      dataType: 'json'
    })
      .done(() => {
        status.textContent = 'Message sent successfully (Ajax demo).';
        status.className = 'text-success';
        // Show thank-you modal
        const modalEl = document.getElementById('orderThanksModal');
        if (modalEl) new bootstrap.Modal(modalEl).show();
        form.reset();
      })
      .fail(() => {
        status.textContent = 'Failed to send. (If offline, this is expected.)';
        status.className = 'text-danger';
      });
  });
})();
