// Utility: currency
const $$$ = n => `$${n.toFixed(2)}`;

// ---- Year in footer
document.addEventListener('DOMContentLoaded', () => {
  const yr = document.getElementById('yr');
  if (yr) yr.textContent = new Date().getFullYear();
});

// ---- jQuery demo: fade in hero title on home
$(function () {
  $('.fade-in-jq').animate({ opacity: 1 }, 900);
});

// ---- Simple front-end cart using localStorage
const CART_KEY = 'it_apple_store_cart';

function loadCart() {
  try { return JSON.parse(localStorage.getItem(CART_KEY)) || []; }
  catch { return []; }
}
function saveCart(items) {
  localStorage.setItem(CART_KEY, JSON.stringify(items));
  updateCartBadge(items);
  renderCart(items);
  renderCartPage(items);
  renderSummary(items);
}
function updateCartBadge(items = loadCart()) {
  const count = items.reduce((sum, it) => sum + it.qty, 0);
  const el = document.getElementById('cartCount');
  if (el) el.textContent = count;
}
function addToCart(product) {
  const items = loadCart();
  const idx = items.findIndex(i => i.id === product.id);
  if (idx >= 0) items[idx].qty += 1;
  else items.push({ ...product, qty: 1 });
  saveCart(items);
}
function removeFromCart(id) {
  const items = loadCart().filter(i => i.id !== id);
  saveCart(items);
}
function setQty(id, qty) {
  const items = loadCart();
  const it = items.find(i => i.id === id);
  if (it) {
    it.qty = Math.max(1, qty|0);
    saveCart(items);
  }
}

// ---- Render mini cart (products page section)
function renderCart(items = loadCart()) {
  const list = document.getElementById('cartItems');
  const totalEl = document.getElementById('cartTotal');
  if (!list || !totalEl) return;

  list.innerHTML = '';
  if (!items.length) {
    list.innerHTML = `<div class="list-group-item">Your cart is empty.</div>`;
    totalEl.textContent = '$0.00';
    return;
  }

  let total = 0;
  items.forEach(it => {
    total += it.price * it.qty;
    const row = document.createElement('div');
    row.className = 'list-group-item d-flex justify-content-between align-items-center';
    row.innerHTML = `
      <div>
        <strong>${it.title}</strong>
        <div class="small text-muted">${it.qty} × ${$$$(it.price)}</div>
      </div>
      <button class="btn btn-sm btn-outline-danger">Remove</button>
    `;
    row.querySelector('button').addEventListener('click', () => removeFromCart(it.id));
    list.appendChild(row);
  });
  totalEl.textContent = $$$(+total);
}

// ---- Render full cart page
function renderCartPage(items = loadCart()) {
  const list = document.getElementById('cartList');
  if (!list) return;
  list.innerHTML = '';

  if (!items.length) {
    list.innerHTML = '<div class="list-group-item py-4 text-center">Your cart is empty.</div>';
    renderSummary(items);
    return;
  }

  items.forEach(it => {
    const row = document.createElement('div');
    row.className = 'list-group-item d-flex align-items-center gap-3';
    row.innerHTML = `
      <img src="${it.img||''}" alt="" class="rounded" style="width:64px;height:64px;object-fit:cover;background:#f2f2f2">
      <div class="flex-fill">
        <div class="d-flex justify-content-between align-items-center">
          <strong>${it.title}</strong>
          <span class="text-muted">${$$$(it.price)}</span>
        </div>
        <div class="mt-2 d-flex align-items-center gap-2">
          <label class="small text-muted me-1">Qty</label>
          <input type="number" min="1" value="${it.qty}" class="form-control form-control-sm" style="width:80px">
          <button class="btn btn-sm btn-outline-danger ms-auto">Remove</button>
        </div>
      </div>
    `;
    const qtyInput = row.querySelector('input[type="number"]');
    qtyInput.addEventListener('change', () => setQty(it.id, +qtyInput.value));
    row.querySelector('button').addEventListener('click', () => removeFromCart(it.id));
    list.appendChild(row);
  });
}

// ---- Summary (cart page)
function renderSummary(items = loadCart()) {
  const subEl = document.getElementById('sumSubtotal');
  const taxEl = document.getElementById('sumTax');
  const ttlEl = document.getElementById('sumTotal');
  if (!subEl || !taxEl || !ttlEl) return;

  const subtotal = items.reduce((s,it)=>s+it.price*it.qty,0);
  const tax = subtotal * 0.07;
  const total = subtotal + tax;
  subEl.textContent = $$$(+subtotal);
  taxEl.textContent = $$$(+tax);
  ttlEl.textContent = $$$(+total);
}

// ---- Home page: show first 4 products
async function fillHomeGrid() {
  if (!$('#homeGrid').length) return;
  try {
    const products = await $.getJSON('assets/products.json');
    const subset = products.slice(0,4);
    const $grid = $('#homeGrid');
    subset.forEach(p => {
      const card = $(`
        <div class="col-6 col-md-3">
          <div class="card h-100">
            <img class="card-img-top" src="${p.img}" alt="${p.title}">
            <div class="card-body d-flex flex-column">
              <h6 class="card-title mb-1">${p.title}</h6>
              <p class="mb-3 fw-semibold">${$$$(+p.price)}</p>
              <a href="products.html" class="btn btn-outline-dark mt-auto">View</a>
            </div>
          </div>
        </div>
      `);
      $grid.append(card);
    });
  } catch(e) {}
}

// ---- Products page Ajax + tick confirmation with sectioned categories
$(async function () {
  updateCartBadge();
  renderCart();
  renderCartPage();
  renderSummary();
  fillHomeGrid();

  const $status = $('#loadStatus');

  const sections = ['iphone','macbook','iwatch','airpod','accessories'];
  const hasSections = sections.some(s => $(`.section-${s}`).length);
  const hasGrid = $('#productGrid').length > 0;
  if (!hasSections && !hasGrid) return; // not on products page

  try {
    const items = await $.getJSON('assets/products.json');
    if ($status.length) $status.text('');

    function attachAdd($btn, p){
      $btn.on('click', function(){
        addToCart({ id: p.id, title: p.title, price: +p.price, img: p.img });
        const original = $btn.text();
        $btn.addClass('btn-success btn-tick').removeClass('btn-dark').text('Added');
        setTimeout(()=>{ $btn.removeClass('btn-success btn-tick').addClass('btn-dark').text(original); }, 1200);
        const toastEl = document.getElementById('addToast');
        if (toastEl) new bootstrap.Toast(toastEl).show();
      });
    }

    if (hasGrid) {
      const $grid = $('#productGrid');
      items.forEach(p => {
        const col = $(`
          <div class="col-6 col-md-4 col-lg-3">
            <div class="card h-100 position-relative">
              <img class="card-img-top" src="${p.img}" alt="${p.title}">
              <div class="card-body d-flex flex-column">
                <h6 class="card-title mb-1">${p.title}</h6>
                <p class="mb-3 fw-semibold">${$$$(+p.price)}</p>
                <button class="btn btn-dark mt-auto add-btn">Add to Cart</button>
              </div>
            </div>
          </div>
        `);
        attachAdd(col.find('.add-btn'), p);
        $grid.append(col);
      });
    } else {
      sections.forEach(cat => {
        const $grid = $(`.section-${cat}`);
        const filtered = items.filter(p => p.category === cat);
        filtered.forEach(p => {
          const col = $(`
            <div class="col-6 col-md-4 col-lg-3">
              <div class="card h-100 position-relative">
                <img class="card-img-top" src="${p.img}" alt="${p.title}">
                <div class="card-body d-flex flex-column">
                  <h6 class="card-title mb-1">${p.title}</h6>
                  <p class="mb-3 fw-semibold">${$$$(+p.price)}</p>
                  <button class="btn btn-dark mt-auto add-btn">Add to Cart</button>
                </div>
              </div>
            </div>
          `);
          attachAdd(col.find('.add-btn'), p);
          $grid.append(col);
        });
      });
    }

  } catch (e) {
    if ($status.length) $status.text('Failed to load products. Run a local server and check assets/products.json.');
  }
});